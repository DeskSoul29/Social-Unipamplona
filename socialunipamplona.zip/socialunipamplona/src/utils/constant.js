// export const API_HOST = "https://social-unipamplona-server.herokuapp.com";
export const API_HOST = "http://localhost:8080";
export const TOKEN = "token";
